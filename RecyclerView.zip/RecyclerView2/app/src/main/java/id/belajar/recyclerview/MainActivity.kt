package id.belajar.recyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*
import id.belajar.recyclerview.Adapter

class MainActivity : AppCompatActivity(), Adapter.ItemListener {

//    val list = ArrayList<Users>()

//    val listUsers = arrayOf(
//        "Google",
//        "Apple",
//        "Xiaomi",
//        "Asus",
//        "Acer",
//        "Toshiba",
//        "Samsung",
//        "Razer",
//        "Dell",
//        "Hewlett Packard",
//        "Microsoft",
//        "Compaq"
//    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//        setSupportActionBar(toolbar)

        mRecyclerView.setHasFixedSize(true)
        mRecyclerView.layoutManager = LinearLayoutManager(this)
        mRecyclerView.adapter = Adapter(getNameList(),this)

//        for (i in 0 until listUsers.size){
//            list.add(Users(listUsers.get(i)))
//            if (listUsers.size - 1 == i) {
//                //init adapter yang telah dibuat
//                val adapter = Adapter(list)
//                adapter.notifyDataSetChanged()
//                //tampilkan data dalam recycler view
//                mRecyclerView.adapter = adapter
//            }
//        }

    }

    fun getNameList () : ArrayList<String>{
        val list = ArrayList<String>()
            list.add("Google")
            list.add("Apple")
            list.add("Xiaomi")
            list.add("Asus")
            list.add("Acer")
            list.add("Toshiba")
            list.add("Samsung")
            list.add("Razer")
            list.add("Dell")
            list.add("Hewlett Packard")
            list.add("Microsoft")
            list.add("Compaq")
        return list
    }

    override fun onClicked(name: String){
        Toast.makeText(this, "Anda memilih "+name,Toast.LENGTH_SHORT).show()
    }


}

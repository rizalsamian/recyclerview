package id.belajar.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView



class Adapter(val list: ArrayList<String>, val listener: ItemListener): RecyclerView.Adapter<Adapter.Holder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        return Holder(LayoutInflater.from(parent.context).inflate(R.layout.list,parent,false))
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
//        holder.view.lbList.text = list?.get(position)?.name
        holder.bindData(list.get(position),listener)
    }

    class Holder(val view: View) : RecyclerView.ViewHolder(view) {
        var txtName = view?.findViewById<TextView>(R.id.lbList)

        fun bindData(name: String, listener: ItemListener){
            txtName?.text = name
            txtName?.setOnClickListener { view -> listener.onClicked(name) }
        }
    }

    interface ItemListener {
        fun onClicked(name : String)
    }

}

